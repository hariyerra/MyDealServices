﻿using MyDealServices.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyDealServices.DataAccess;
using MyDealServices.DataAccess.Models;
using System.Threading.Tasks;
using MyDealServices.Utility.UIHelpers;
using MyDealServices.Utility.ConfigHelper;
using MyDealServices.Model;
using System.Text.RegularExpressions;

namespace MyDealServices.Utility.DataAccessHelpers
{
    public class PNLRepository : IPNLRepository
    {

        public List<BookingDetails> ProcessPNLData(string PNLData)
        {
            List<BookingDetails> returnData = null;
            try
            {
                var regex = new Regex(@"(1)([A-Z a-z 0-9]+)(/)([A-Z a-z 0-9]+)(-)([A-Z a-z]{1}\d{1})( )(.L/)([A-Z a-z 0-9]{6})$");

                var datalines = PNLData.Split(Environment.NewLine.ToCharArray());

                var processed = from pnlItem in datalines
                                where pnlItem.StartsWith("1")
                                let rg = regex.Match(pnlItem)
                                select new Passenger()
                                {
                                    FirstName = rg.Groups[2].Value,
                                    LastName = rg.Groups[4].Value.EndsWith("MR") ? rg.Groups[4].Value.Substring(0, rg.Groups[4].Value.Length - 2) : rg.Groups[4].Value.Substring(0, rg.Groups[4].Value.Length - 3),
                                    Title = (rg.Groups[4].Value.EndsWith("MR") ? "MR" : "MRS"),
                                    RecordLocator = rg.Groups[9].Value
                                };

                var grouped = from item in processed.ToList()
                              group item by item.RecordLocator into grp
                              select new BookingDetails
                              {
                                  RecordLocator = grp.Key,
                                  Passengers = grp.ToArray()
                              };
                returnData = grouped.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return returnData;
        }
    }
}