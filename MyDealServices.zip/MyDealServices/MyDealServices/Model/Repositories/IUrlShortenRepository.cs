﻿using MyDealServices.DataAccess.Models;
using MyDealServices.ViewModels;
using System.Threading.Tasks;

namespace MyDealServices.Utility.DataAccessHelpers
{
    public interface IUrlShortenRepository
    {
        URLModel ShortenUrl(URLModel newUrl);

        URLModel CheckLongUrlExists(string LongUrl);
    }
}