﻿using MyDealServices.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyDealServices.Model
{
    public class BookingDetails
    {
        public string RecordLocator { get; set; }
        public Passenger[] Passengers { get; set; }
    }
}