﻿using MyDealServices.Utility.DataAccessHelpers;
using MyDealServices.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using MyDealServices.Utility.UIHelpers;
using MyDealServices.DataAccess.Models;

namespace MyDealServices.api
{
    /// <summary>
    /// This Web API can be consumed to shorten the long URLs of mydeal.com domian
    /// </summary>
    //[RoutePrefix("api/URLShorten")]
    public class URLShorteningController : ApiController
    {
        Status _status;
        IUrlShortenRepository _urlRepo;

        public URLShorteningController(IUrlShortenRepository urlRepo)
        {
            _urlRepo = urlRepo;
        }

     //   [Route("getShortendURL")]
        [HttpPost]
        public IHttpActionResult ShortenUrl(string LongUrl)
        {

            if (ModelState.IsValid)
            {
                //perform some validations
                if (string.IsNullOrEmpty(LongUrl))
                {
                    _status = new Status()
                    {
                        ReturnStatus = UIConstants.MESSAGE_ERROR,
                        ErrorMessage = "Given URL is empty."
                    };
                    return new JsonHttpResponseResult(_status, Request);
                }

                //Check whether url is valid
                if (!UrlHelper.IsValidLongUrl(LongUrl))
                {
                    _status = new Status()
                    {
                        ReturnStatus = UIConstants.MESSAGE_ERROR,
                        ErrorMessage = "Only Uri’s of mydeal.com.au can be shortened"
                    };

                    return new JsonHttpResponseResult(_status, Request);
                }

                //check whether longUrl shrotened already
                var existingurl = _urlRepo.CheckLongUrlExists(LongUrl);

                //if Url not exists, create new Short URL and return it to user
                if (existingurl == null)
                {
                    URLModel shortUrl = new URLModel()
                    {
                        LongUrl = LongUrl
                    };

                    var newshorturl = _urlRepo.ShortenUrl(shortUrl);

                    _status = new Status()
                    {
                        ReturnStatus = UIConstants.MESSAGE_SUCCESS,
                        ReturnData = newshorturl
                    };

                    return new JsonHttpResponseResult(_status, Request);
                }
                else
                {
                    //return the existing URL to user
                    _status = new Status()
                    {
                        ReturnStatus = UIConstants.MESSAGE_SUCCESS,
                        ResponseMessage = "Shortened URL already exisits for the given URL.",
                        ReturnData = existingurl
                    };

                    return new JsonHttpResponseResult(_status, Request);
                }
            }
            else
            {
                _status = new Status()
                {
                    ReturnStatus = UIConstants.MESSAGE_ERROR,
                    ErrorMessage = "Error while processing the data."
                };

                return new JsonHttpResponseResult(_status, Request);
            }
            
        }

    }


}
