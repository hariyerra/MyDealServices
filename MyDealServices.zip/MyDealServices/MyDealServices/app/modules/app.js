(function () {
    'use strict';
    var app = angular.module('mydealApp', []);
})();
//# sourceMappingURL=app.js.map