﻿using MyDealServices.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyDealServices.DataAccess
{
    public class UrlShortenContext : DbContext
    {
        public UrlShortenContext() : base("name=UrlConnStr")
        {

        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
               
        }

        public DbSet<URLModel> Urls { get; set; }

    }
}
