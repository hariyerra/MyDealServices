var mydealApp;
(function (mydealApp) {
    var services;
    (function (services) {
        'use strict';
        var UrlService = (function () {
            function UrlService($http, $rootScope) {
                this.$http = $http;
                this.GET_METHOD = "GET";
                this.POST_METHOD = "POST";
                this.ShortendUrl = "/api/URLShortening/ShortenUrl";
                this.rootScope = $rootScope;
            }
            UrlService.prototype.getShortendUrl = function (longUrl) {
                debugger;
                return this.$http({
                    method: this.POST_METHOD,
                    url: this.ShortendUrl,
                    params: {
                        'LongUrl': longUrl
                    }
                });
            };
            UrlService.$inject = ['$http', '$rootScope'];
            return UrlService;
        }());
        services.UrlService = UrlService;
        angular.module('mydealApp')
            .service('mydealApp.services.UrlService', UrlService);
    })(services = mydealApp.services || (mydealApp.services = {}));
})(mydealApp || (mydealApp = {}));
//# sourceMappingURL=UrlService.js.map