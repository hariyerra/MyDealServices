var mydealApp;
(function (mydealApp) {
    var services;
    (function (services) {
        'use strict';
        var PNLService = (function () {
            function PNLService($http, $rootScope) {
                this.$http = $http;
                this.GET_METHOD = "GET";
                this.POST_METHOD = "POST";
                this.showPNLUrl = "/PNL/ShowPNL";
                this.addPNLUrl = "/PNL/AddPassenger";
                this.rootScope = $rootScope;
            }
            PNLService.prototype.showPNL = function () {
                debugger;
                return this.$http({
                    method: this.GET_METHOD,
                    url: this.showPNLUrl
                });
            };
            PNLService.prototype.addPassenger = function (newPassenger) {
                return this.$http({
                    method: this.POST_METHOD,
                    url: this.addPNLUrl,
                    params: {
                        'newPassenger': newPassenger
                    }
                });
            };
            PNLService.$inject = ['$http', '$rootScope'];
            return PNLService;
        }());
        services.PNLService = PNLService;
        angular.module('mydealApp')
            .service('mydealApp.services.PNLService', PNLService);
    })(services = mydealApp.services || (mydealApp.services = {}));
})(mydealApp || (mydealApp = {}));
//# sourceMappingURL=PNLService.js.map