﻿using MyDealServices.Model;
using MyDealServices.Utility.Common;
using MyDealServices.Utility.ConfigHelper;
using MyDealServices.Utility.ServiceClient;
using MyDealServices.Utility.UIHelpers;
using MyDealServices.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace MyDealServices.Controllers
{
    public class PNLController : Controller
    {
        string PNLfilePath = ConfigurationSettings.PNLFilePath;
        IApiClient _apiClient;
  
        public PNLController(IApiClient apiClient)
        {
            _apiClient = apiClient;
        }

        // GET: PNL
        public ActionResult Index()
        {  
            return View();
        }
        
        public async Task<ActionResult> ShowPNL()
        {

            string returnData = string.Empty;
            List<BookingDetails> responseData = null;

            //1. Read the file and send the contents to Web API
            TextFileReader reader = new TextFileReader(PNLfilePath);

            string contents = reader.ReadContent();

            //2. Pass the PNLData to Web api for further processing
            if (!string.IsNullOrEmpty(contents))
            {
                responseData = await _apiClient.ProcessPNLData(contents);

                var groupedData = responseData.GroupBy(g => g.RecordLocator).ToList();

                returnData = JsonConvert.SerializeObject(groupedData);
            }

            return new ContentResult() { Content = returnData, ContentType = "application/json" };
        }

        [HttpPost]
        public async Task<ActionResult> AddPassenger(string newPassenger)
        {
            //append to the text file
            if (ModelState.IsValid)
            {
                TextFileWriter writer = new Utility.Common.TextFileWriter(PNLfilePath);
                var IsAdded = await writer.WriteContent(newPassenger);

                if (IsAdded)
                    return new ContentResult() { Content = "New passenger added sucessfully.", ContentType = "application/text" };
                else
                    return new ContentResult() { Content = "Error during adding. Please try again.", ContentType = "application/text" };
            }
            else
            {
                return new ContentResult() { Content = "Please correct the data before adding.", ContentType = "application/text" };
            }
            
        }
    }
}