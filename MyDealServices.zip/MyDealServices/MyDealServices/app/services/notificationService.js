var mydealApp;
(function (mydealApp) {
    var services;
    (function (services) {
        'use strict';
        var NotificationService = (function () {
            function NotificationService() {
                toastr.options.closeButton = true;
                toastr.options.debug = false;
                toastr.options.positionClass = "toast-top-right";
                toastr.options.showDuration = 500;
                toastr.options.hideDuration = 4000;
                toastr.options.timeOut = 5000;
                toastr.options.extendedTimeOut = 3000;
                toastr.options.showEasing = "swing";
                toastr.options.hideEasing = "linear";
                toastr.options.showMethod = "fadeIn";
                toastr.options.hideMethod = "fadeOut";
            }
            NotificationService.prototype.displaySuccess = function (message) {
                toastr.success(message, 'success');
            };
            NotificationService.prototype.displayError = function (message) {
                toastr.error(message, 'error');
            };
            NotificationService.prototype.displayWarning = function (message) {
                toastr.warning(message, 'warning');
            };
            NotificationService.prototype.displayInfo = function (message) {
                toastr.info(message, 'info');
            };
            NotificationService.prototype.alert = function (message, callback) {
                var alertOptions = {
                    message: message,
                    size: 'small',
                    callback: callback
                };
                bootbox.alert(alertOptions);
            };
            return NotificationService;
        }());
        services.NotificationService = NotificationService;
        angular.module('mydealApp')
            .service('mydealApp.services.NotificationService', NotificationService);
    })(services = mydealApp.services || (mydealApp.services = {}));
})(mydealApp || (mydealApp = {}));
//# sourceMappingURL=notificationService.js.map