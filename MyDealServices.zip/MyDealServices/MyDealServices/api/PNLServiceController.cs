﻿using MyDealServices.Model;
using MyDealServices.Utility.DataAccessHelpers;
using MyDealServices.Utility.UIHelpers;
using MyDealServices.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyDealServices.api
{
    [RoutePrefix("api/PNLService")]
    public class PNLServiceController : ApiController
    {
        Status _status;
        IPNLRepository pnlRepo;

        public PNLServiceController(IPNLRepository _pnlRepo)
        {
            pnlRepo = _pnlRepo;
        }

        [Route("Process")]
        [HttpPost]
        public IHttpActionResult ProcessPNLData([FromBody] string PNLData)
        {
            List<BookingDetails> passengerList = null;
            try
            {
                passengerList = pnlRepo.ProcessPNLData(PNLData);

                _status = new Status()
                {
                    ReturnStatus = UIConstants.MESSAGE_SUCCESS,
                    ReturnData = passengerList
                };

            }
            catch (Exception ex)
            {
                _status = new Status()
                {
                    ReturnStatus = UIConstants.MESSAGE_ERROR,
                    ReturnData = null,
                    ErrorMessage=ex.Message
                };
            }

            return new JsonHttpResponseResult(_status, Request);
        }
    }
}
