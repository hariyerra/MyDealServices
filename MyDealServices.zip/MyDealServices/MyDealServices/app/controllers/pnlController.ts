﻿module mydealApp.controllers {
    export class pnlController {
        static $inject = ['$scope', 'mydealApp.services.PNLService', 'mydealApp.services.NotificationService'];

        constructor(private $scope: any,
            private pnlService: mydealApp.services.PNLService,
            private notificationService: mydealApp.services.NotificationService
        ) {
            var self = this;
            self.$scope = $scope;
            self.$scope.showAddPanel = false;
            self.$scope.newPassenger = "";

            self.$scope.getBookingDetails = function () {
                //fetch the booking details
                debugger;
                pnlService.showPNL()
                    .then(function (result) {
                        console.log(result);
                        self.$scope.bookingDetail = result.data;
                    },
                    function (reason) {
                        console.log(reason);
                    });
            };

            self.$scope.showAdd = function () {
                self.$scope.showAddPanel = true;
            }

            self.$scope.AddPassenger = function () {
                //call MVC method post
                pnlService.addPassenger(self.$scope.newPassenger)
                    .then(function (result) {
                        debugger;
                        console.log(result);
                        notificationService.displaySuccess(result.data);
                        self.$scope.showAddPanel = false;
                        self.$scope.newPassenger = "";
                        //refresh the list
                        self.$scope.getBookingDetails();
                    },
                    function (reason) {
                        console.log(reason);
                        notificationService.displayError(reason.data);
                    });
            }
        }
    }

    angular.module('mydealApp')
        .controller('mydealApp.controllers.pnlController', pnlController);

}