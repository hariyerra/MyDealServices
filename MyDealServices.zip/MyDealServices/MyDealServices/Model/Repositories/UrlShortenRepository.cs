﻿using MyDealServices.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyDealServices.DataAccess;
using MyDealServices.DataAccess.Models;
using System.Threading.Tasks;
using MyDealServices.Utility.UIHelpers;
using MyDealServices.Utility.ConfigHelper;

namespace MyDealServices.Utility.DataAccessHelpers
{
    public class UrlShortenRepository : IUrlShortenRepository
    {
        UrlShortenContext _dbContext;

        public UrlShortenRepository()
        {
            _dbContext = new UrlShortenContext();
        }

        public URLModel ShortenUrl(URLModel newUrl)
        {
            try
            {
                //Generate short URLand map it to long url
                newUrl.ShortUrl = string.Concat(ConfigurationSettings.ValidDomianAddress, GenerateShortUrl());

                _dbContext.Urls.Add(newUrl);

                _dbContext.SaveChanges();

                return newUrl;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public URLModel CheckLongUrlExists(string LongUrl)
        {
            try
            {
                var url = _dbContext.Urls.Where(u => u.LongUrl.ToLower() == LongUrl.ToLower()).FirstOrDefault();
                return url;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GenerateShortUrl()
        {
            try
            {
                //loop thorugh until generates unique GUID portion
                while (true)
                {
                    //keeping shortUrl length to 7 characters
                    string GeneratedshortUrl = Guid.NewGuid().ToString().Substring(0, 7);

                    if (!_dbContext.Urls.Where(u => u.ShortUrl == GeneratedshortUrl).Any())
                    {
                        return GeneratedshortUrl;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}