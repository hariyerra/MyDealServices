﻿module mydealApp.services {
    'use strict';

    export class NotificationService {
        constructor() {
            toastr.options.closeButton = true;
            toastr.options.debug = false;
            toastr.options.positionClass = "toast-top-right";
            toastr.options.showDuration = 500;
            toastr.options.hideDuration = 4000;
            toastr.options.timeOut = 5000;
            toastr.options.extendedTimeOut = 3000;
            toastr.options.showEasing = "swing";
            toastr.options.hideEasing = "linear";
            toastr.options.showMethod = "fadeIn";
            toastr.options.hideMethod = "fadeOut";

        }

        displaySuccess(message: string): void {
            toastr.success(message, 'success');
        }

        displayError(message: string): void {
            toastr.error(message, 'error');
        }

        displayWarning(message: string): void {
            toastr.warning(message, 'warning');
        }

        displayInfo(message: string): void {
            toastr.info(message, 'info');
        }

        alert(message: string, callback?: () => any): void {
            let alertOptions: BootboxAlertOptions = {
                message: message,
                size: 'small',
                callback: callback
            };
            bootbox.alert(alertOptions);
        }

    }

    angular.module('mydealApp')
        .service('mydealApp.services.NotificationService', NotificationService);
}