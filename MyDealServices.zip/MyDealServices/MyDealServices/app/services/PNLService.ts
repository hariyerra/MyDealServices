﻿module mydealApp.services {
    'use strict';

    export interface IPNLService {
        showPNL(): ng.IPromise<any>,
        addPassenger(newPassenger: any): ng.IPromise<any>
    }

    export class PNLService implements IPNLService {
        private GET_METHOD: string = "GET";
        private POST_METHOD: string = "POST";
        private showPNLUrl: string = "/PNL/ShowPNL";
        private addPNLUrl: string = "/PNL/AddPassenger";

        static $inject = ['$http', '$rootScope'];
        private rootScope: ng.IRootScopeService;


        constructor(private $http: ng.IHttpService, $rootScope: ng.IRootScopeService) {
            this.rootScope = $rootScope;
        }

        showPNL(): ng.IPromise<any> {
            debugger;
            return this.$http({
                method: this.GET_METHOD,
                url: this.showPNLUrl
            });
        }

        addPassenger(newPassenger: any): ng.IPromise<any> {
            return this.$http({
                method: this.POST_METHOD,
                url: this.addPNLUrl,
                params: {
                    'newPassenger': newPassenger
                }
            });
        }
    }

    angular.module('mydealApp')
        .service('mydealApp.services.PNLService', PNLService);
}