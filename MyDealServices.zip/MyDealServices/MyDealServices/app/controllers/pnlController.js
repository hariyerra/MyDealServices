var mydealApp;
(function (mydealApp) {
    var controllers;
    (function (controllers) {
        var pnlController = (function () {
            function pnlController($scope, pnlService, notificationService) {
                this.$scope = $scope;
                this.pnlService = pnlService;
                this.notificationService = notificationService;
                var self = this;
                self.$scope = $scope;
                self.$scope.showAddPanel = false;
                self.$scope.newPassenger = "";
                self.$scope.getBookingDetails = function () {
                    //fetch the booking details
                    debugger;
                    pnlService.showPNL()
                        .then(function (result) {
                        console.log(result);
                        self.$scope.bookingDetail = result.data;
                    }, function (reason) {
                        console.log(reason);
                    });
                };
                self.$scope.showAdd = function () {
                    self.$scope.showAddPanel = true;
                };
                self.$scope.AddPassenger = function () {
                    //call MVC method post
                    pnlService.addPassenger(self.$scope.newPassenger)
                        .then(function (result) {
                        debugger;
                        console.log(result);
                        notificationService.displaySuccess(result.data);
                        self.$scope.showAddPanel = false;
                        self.$scope.newPassenger = "";
                        //refresh the list
                        self.$scope.getBookingDetails();
                    }, function (reason) {
                        console.log(reason);
                        notificationService.displayError(reason.data);
                    });
                };
            }
            pnlController.$inject = ['$scope', 'mydealApp.services.PNLService', 'mydealApp.services.NotificationService'];
            return pnlController;
        }());
        controllers.pnlController = pnlController;
        angular.module('mydealApp')
            .controller('mydealApp.controllers.pnlController', pnlController);
    })(controllers = mydealApp.controllers || (mydealApp.controllers = {}));
})(mydealApp || (mydealApp = {}));
//# sourceMappingURL=pnlController.js.map