﻿module mydealApp.services {
    'use strict';

    export interface IUrlService {
        getShortendUrl(longUrl: any): ng.IPromise<any>
    }

    export class UrlService implements IUrlService  {

        private GET_METHOD: string = "GET";
        private POST_METHOD: string = "POST";
        private ShortendUrl: string = "/api/URLShortening/ShortenUrl";

        static $inject = ['$http', '$rootScope'];
        private rootScope: ng.IRootScopeService;


        constructor(private $http: ng.IHttpService, $rootScope: ng.IRootScopeService) {
            this.rootScope = $rootScope;
        }

        getShortendUrl(longUrl: any): ng.IPromise<any> {
            debugger;
            return this.$http({
                method: this.POST_METHOD,
                url: this.ShortendUrl,
                params: {
                    'LongUrl': longUrl
                }
            });
        }
    }



    angular.module('mydealApp')
        .service('mydealApp.services.UrlService', UrlService);

}