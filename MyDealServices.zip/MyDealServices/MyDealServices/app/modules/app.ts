﻿((): void => {
    'use strict';
    var app = angular.module('mydealApp', []);
})();