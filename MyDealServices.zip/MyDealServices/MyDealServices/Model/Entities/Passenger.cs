﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyDealServices.Model
{
    public class Passenger
    {
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string RecordLocator { get; set; }
    }
}