﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System;

namespace MyDealServices.DataAccess.Models
{
    public class URLModel
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [Url(ErrorMessage ="Invalid URL format")]
        [DisplayName("Long URL")]
        public string LongUrl { get; set; }
        
        [Required]
        [DisplayName("Shortend URL")]
        public string ShortUrl { get; set; }
        
    }
}