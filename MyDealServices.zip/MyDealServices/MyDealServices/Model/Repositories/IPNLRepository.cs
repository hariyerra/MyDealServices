﻿using MyDealServices.DataAccess.Models;
using MyDealServices.Model;
using MyDealServices.ViewModels;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyDealServices.Utility.DataAccessHelpers
{
    public interface IPNLRepository
    {
        List<BookingDetails> ProcessPNLData(string PNLData);
    }
}