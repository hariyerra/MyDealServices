var mydealApp;
(function (mydealApp) {
    var controllers;
    (function (controllers) {
        var urlController = (function () {
            function urlController($scope, urlService, notificationService) {
                this.$scope = $scope;
                this.urlService = urlService;
                this.notificationService = notificationService;
                var self = this;
                self.$scope = $scope;
                self.$scope.welcome = "Hi This is welcome message";
                self.$scope.LongUrl = "";
                self.$scope.ShortUrl = "";
                self.$scope.ShowShortUrl = false;
                self.$scope.isLoading = false;
                self.$scope.btnText = "Shorten URL";
                self.$scope.ShortenUrl = function () {
                    self.$scope.isLoading = true;
                    //call Url shortening service
                    urlService.getShortendUrl(self.$scope.LongUrl)
                        .then(function (response) {
                        console.log(response.data);
                        debugger;
                        if (response.data.returnStatus == "success") {
                            if (response.data.responseMessage != null) {
                                self.$scope.ShowShortUrl = true;
                                self.$scope.ShortUrl = response.data.returnData.shortUrl;
                                notificationService.displayWarning(response.data.responseMessage);
                            }
                            else {
                                self.$scope.ShowShortUrl = true;
                                self.$scope.ShortUrl = response.data.returnData.shortUrl;
                                notificationService.displayInfo("Long Url is shortened succcessfully!");
                            }
                        }
                        else if (response.data.returnStatus == "error") {
                            self.$scope.ShowShortUrl = false;
                            self.$scope.ShortUrl = "";
                            notificationService.displayError(response.data.errorMessage);
                        }
                        self.$scope.isLoading = false;
                    }, function (reason) {
                        //error
                        console.log(reason);
                        self.$scope.ShowShortUrl = false;
                        self.$scope.ShortUrl = "";
                        notificationService.displayError("Error Occured:" + reason);
                        self.$scope.isLoading = false;
                    });
                };
            }
            urlController.$inject = ['$scope', 'mydealApp.services.UrlService', 'mydealApp.services.NotificationService'];
            return urlController;
        }());
        controllers.urlController = urlController;
        angular.module('mydealApp')
            .controller('mydealApp.controllers.urlController', urlController);
    })(controllers = mydealApp.controllers || (mydealApp.controllers = {}));
})(mydealApp || (mydealApp = {}));
//# sourceMappingURL=urlController.js.map